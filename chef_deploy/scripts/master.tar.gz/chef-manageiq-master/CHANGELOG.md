chef-manageiq CHANGELOG
=========================

This file is used to list changes made in each version of the chef-manageiq cookbook.

0.1.0
-----
- [BoozAllen] - Initial release of chef-manageiq
